#ifndef CONSTANT_H
#define CONSTANT_H

#define G 6.67408e-11
#define EPSILON2 (0.005*0.005)
#define DELTAT 0.1

#define ADJ_CELLS 8

#endif // CONSTANT_H
